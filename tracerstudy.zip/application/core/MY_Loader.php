<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* load the HMVC_Loader class */
require APPPATH . 'third_party/MX/Loader.php';

class MY_Loader extends HMVC_Loader {
}
